package com.niit.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDao;

import com.niit.model.User;

public class UserDaoTest {
	static UserDao userDao;

	@BeforeClass
	public static void initialize() {
		AnnotationConfigApplicationContext annotationConfigAppContext = new AnnotationConfigApplicationContext();

		annotationConfigAppContext.scan("com.niit.*");
		annotationConfigAppContext.refresh();
		userDao = (UserDao) annotationConfigAppContext.getBean("userDao");
	}

	@Test

	public void saveTest() {
		User user = new User();
		user.setAddress("chennai,India");
		user.setEmail("sasi@gmail.com");
		user.setMobno(937750319);
		user.setUsername("Sasireka");
		user.setPassword("123");
		user.setRole("user");
		assertTrue("problem in creating user details", userDao.save(user));

	}

}
