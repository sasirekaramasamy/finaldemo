package com.niit.daoImpl;

import org.springframework.stereotype.Repository;

import com.niit.dao.CartProductDao;
import com.niit.model.Cart;

@Repository("cartProductDao")
public class CartProductDaoImpl implements CartProductDao{
	
	
	@Override
	public boolean update(Cart cart) {
		
		return false;
	}

}
