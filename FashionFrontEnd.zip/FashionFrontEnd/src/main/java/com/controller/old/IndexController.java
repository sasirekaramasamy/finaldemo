package com.controller.old;

import org.springframework.stereotype.Controller;
/*
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.*;
import com.niit.model.*;
import com.niit.daoImpl.*;

*/

@Controller
public class IndexController {
	
	/*
	@Autowired
	private UserDaoImpl userDao;


	
	@RequestMapping(value="/Index")
	public ModelAndView index()
	{
		ModelAndView mv=new ModelAndView("Index");
		
		return mv;
	}
	/*
	@RequestMapping(value="/Register", method=RequestMethod.POST)
	 public ModelAndView saveUser(@ModelAttribute User user)
	 {
		userDAO.InsertUser(user);
		
		 ModelAndView mv=new ModelAndView();
		return mv;
		 
	 }
/*
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("Register");
	    mav.addObject("user", new User());
	    return mav;
	  }
	  @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,  @ModelAttribute("user") User user) {
		  
		  System.out.println("USER DETAILS :"+user);
		  userDao.addUser(user);
		  
	  return new ModelAndView("welcome", "firstname", user.getName());
	  }
	  
	  */
}
