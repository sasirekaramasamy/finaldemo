package com.niit.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.niit.dao.ProductDao;
import com.niit.model.Category;
import com.niit.model.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDao productDao;
	
	/*
    @RequestMapping("/save-product")
    public String uploadResources( HttpServletRequest servletRequest,
                                 @ModelAttribute Product product,
                                 Model model)
    {
        //Get the uploaded files and store them
        List<MultipartFile> files = product.getImages();
        List<String> fileNames = new ArrayList<String>();
        if (null != files && files.size() > 0)
        {
            for (MultipartFile multipartFile : files) {
 
                String fileName = multipartFile.getOriginalFilename();
                fileNames.add(fileName);
 
                File imageFile = new File(servletRequest.getServletContext().getRealPath("./resources/images"), fileName);
                try
                {
                    multipartFile.transferTo(imageFile);
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
 
        // Here, you can save the product details in database
         
        model.addAttribute("product", product);
        return "viewProductDetail";
    }
     
*/
	
	//Insert product		
	  @RequestMapping(value = "/productProcess", method = RequestMethod.POST)
	  public String productProcess(HttpServletRequest servletRequest, @RequestParam String action,  @ModelAttribute("product")Product product,@RequestParam("file")MultipartFile file) {		  
		  
		  if(action.equals("Edit")){

			  System.out.println("EDIT,PRODUCT DETAILS:"+product);
		  boolean result=productDao.update(product);
		  System.out.println("PRODUCT EDIT:"+result);
		  }
		  else if(action.equals("Save")){
			  System.out.println("PRODUCT DETAILS:"+product);
			  
			  String filePath=servletRequest.getSession().getServletContext().getRealPath("/");
			  String filename=file.getOriginalFilename();
			  product.setProductImage(filename);
			  
			  try {
				  byte imageByte[]=file.getBytes();
				  BufferedOutputStream fos=new BufferedOutputStream(new FileOutputStream(filePath+"/resources/images"+filename));
				  fos.write(imageByte);
				  fos.close();
			  }
			  catch(Exception e) {}
			  
			  /*
		        //Get the uploaded files and store them
		        List<MultipartFile> files = product.getImages();
		        List<String> fileNames = new ArrayList<String>();
		        if (null != files && files.size() > 0)
		        {
		            for (MultipartFile multipartFile : files) {
		 
		                String fileName = multipartFile.getOriginalFilename();
		                fileNames.add(fileName);
		 
		                File imageFile = new File(servletRequest.getServletContext().getRealPath("./resources/images"), fileName);
		                try
		                {
		                    multipartFile.transferTo(imageFile);
		                } catch (IOException e)
		                {
		                    e.printStackTrace();
		                }
		            }
		        }
		 */			  
//			  int categoryId=Integer.parseInt(servletRequest.getParameter("categoryId"));
//			  product.getCategory().setCategoryId();
			  			  
//			  int supplierId=Integer.parseInt(servletRequest.getParameter("supplierId"));
//			  product.getSupplier().setSupplierId(supplierId);
			  
			  productDao.addProduct(product);
		  }
		  else if(action.equals("Delete")){
			  System.out.println("DELETE,PRODUCT DETAILS:"+product);
			  boolean result=productDao.delete(product);
			  System.out.println("PRODUCT DELETE:"+result);
		  }
		  else {
			  
		  }


	  return "welcome";
	  }
}
