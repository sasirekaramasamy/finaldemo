package com.niit.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.SupplierDao;
import com.niit.model.Category;
import com.niit.model.Supplier;

@Controller
public class SupplierController {

	@Autowired
	SupplierDao supplierDao;

	// Supplier UI
	@RequestMapping(value = "/supplier")
	public ModelAndView supplierPage() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("userClickSupplier", true);
		System.out.println("inside supplier controller supplierPage method..");
		return mv;
	}

	// Insert supplier into Database
	@RequestMapping(value = "/supplierProcess", method = RequestMethod.POST)
	public ModelAndView addCategory(@RequestParam String action,@ModelAttribute("supplier") Supplier supplier) 
	{				
		  if(action.equals("Edit")){

				System.out.println("EDIT,SUPPLIER DETAILS :" + supplier);
		  boolean result=supplierDao.update(supplier);
		  System.out.println("SUPPLIER EDIT:"+result);
		  }
		  else if(action.equals("Save")){
				System.out.println("SAVE,SUPPLIER DETAILS :" + supplier);
				supplierDao.save(supplier);
		  }
		  else if(action.equals("Delete")){
			  System.out.println("DELETE,SUPPLIER DETAILS :" + supplier);
			  boolean result=supplierDao.delete(supplier);
			  System.out.println("SUPPLIER DELETE:"+result);
		  }
		  else {
			  
		  }

		return new ModelAndView("viewSupplier");
	}
	
/*	
	//Fetch all suppliers		
	  @RequestMapping(value = "/fetchSuppliers", method = RequestMethod.GET)
	  public String fetchAllSuppliers(Model model) {
		  List<Supplier> supplierList=null;			 			  
		  supplierList=supplierDao.getAllSuppliers();
		  for(int i=0;i<supplierList.size();i++) {
			  System.out.println("SUPPLIER DETAILS :"+(Supplier)supplierList.get(i));
		  }
		  model.addAttribute("supplierList",supplierList);
	  return "admin";
	  }
*/

}
